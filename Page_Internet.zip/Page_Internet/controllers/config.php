<?php 
    define('BASE_URL', '/php/PHP_Programmation_Objet/Page_Internet'); 
?>
