<footer>
    <hr>
    <p>&copy; <?= date('Y') ?> Location de véhicules. Tous droits réservés.</p>
</footer>
